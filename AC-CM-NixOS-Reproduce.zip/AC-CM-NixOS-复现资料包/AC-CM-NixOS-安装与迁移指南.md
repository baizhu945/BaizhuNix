# NixOS 上安装 Content Manager、CSP 并启动 Assetto Corsa

**适用对象：baizhu945 的传统 NixOS 配置；最后核对日期：2026-10-13。**

这份指南记录 2026-10-05 实际排障成功的路线，并与现存配置、安装记录及后续启动日志核对。目标是：Steam 的 **PLAY → Content Manager → 进入 AC 赛道**，同时具备安装车辆、赛道等模组的基础环境。

范围按你确认的《Content Manager从下载到卸载 | 2024 神力科莎CM启动器教程 #01》确定：**CM + CSP**。没有把 Sol、Pure、付费 RainFX 或某个车辆/赛道整合包当作必需组件。[原视频](https://www.bilibili.com/video/BV14k4y1U7q2/)

## 1. 先了解成功配置

| 项目 | 已验证基线 | 作用 |
|---|---|---|
| 系统配置 | `/etc/nixos/configuration.nix`，传统 Nix，无 flake | 安装 Steam、Protontricks 和固定 GE |
| Steam | 原生 NixOS Steam，默认 Linux 库 | 下载正版 AC、处理运行时与账号 |
| AC App ID | `244210` | CM 与游戏共享这个兼容前缀 |
| Proton | **GE-Proton9-20** | 已验证的 Windows 兼容运行环境 |
| Steam Linux Runtime | 3.0，代号 `sniper` | Steam 根据 GE 依赖自动下载安装 |
| CM | **0.8.2895.40668，x86，Lite** | 游戏入口及模组管理；原下载文件较旧，后来更新到此版本 |
| Microsoft .NET Framework | **4.8** | 原生 CLR/WPF；安装记录包含先安装 4.0，再升级 4.8 |
| Direct3D 辅助库 | `d3dx11_43`、`d3dcompiler_47` | CM/CSP 所需兼容库 |
| GDI+ | Winetricks `gdiplus`，native override | 修复字体创建访问异常 |
| 字体 | `corefonts` + Segoe UI/Verdana 常规字体；前缀内中文字体 | 避免默认字体与回退字体缺失 |
| CSP | **0.2.11，build 3465** | 基础画面、灯光及模组扩展 |
| CM 辅助数据 | **245** | 图标、国家/品牌信息、分类与快速筛选 |
| 字体隔离 | 在 Proton 入口、初始化前，仅对 AC 生效 | 避免 32 位启动器加载整个宿主字体库 |

这是可复现的**固定基线**，不是“版本越新越好”的保证。CM 的 `tested.zip` 和数据包的 `latest` 是移动下载链接；以后版本可能变化。迁移时保存当前能用的 CM 文件与安装包，比只保留下载地址更可靠。

### 为什么不能只运行 `wine AssettoCorsa.exe`

Steam 创建的环境与默认 `~/.wine` 是两个前缀。直接运行普通 Wine 通常不会使用 AC 的前缀，也不会经过本指南的 AC 字体隔离入口。CM 和 AC 应共同使用 `244210` 的 Proton 环境。[Proton FAQ](https://github.com/ValveSoftware/Proton/wiki/Proton-FAQ#how-does-proton-manage-wine-prefixes)、[Protontricks 文档](https://github.com/Matoking/protontricks#command-line)

当时的问题包括：原版启动器的 `CEF3` 程序集/依赖加载失败、GDI+ 字体创建访问异常、32 位进程字体映射耗尽地址空间，以及缺失回退字体。单看 `TypeLoadException` 不能证明 `CEF3.dll` 文件丢失；本机的文件实际存在。不要从陌生 DLL 网站下载同名文件来覆盖它。

## 2. 更换硬件时，先选择迁移还是重装

### 系统和硬盘继续保留

1. 根据新硬件调整 NixOS 的硬件/显卡驱动模块，并完成系统重建。
2. 保留游戏目录、`244210` 前缀和 CM 设置；先尝试启动，不必主动重建前缀。
3. 重新检查 Steam 的兼容工具仍是 GE-Proton9-20，启动项仍正确。
4. 若出现明确的新兼容问题，再使用下文的备份和重建前缀路线。

### 重装同一 NixOS 或迁移到另一块硬盘

执行第 3～13 节。若已有完整备份，可以先恢复游戏/前缀，再补齐声明式 Nix 配置与失效链接。

### 硬件条件

- 本基线面向 **x86_64 Intel/AMD**。更换为 ARM 不是这份固定 GE 压缩包支持的直接迁移。
- 显卡驱动和 32 位图形支持必须与新显卡匹配。原机器是 NVIDIA + Intel；改用 AMD/其他显卡时，应调整对应 NixOS 驱动配置，不能照搬旧 NVIDIA 参数。
- 游戏库使用 ext4/btrfs 等 Linux 文件系统。这次成功安装位于 ext4。Windows NTFS 分区会给 Proton 前缀、文件名和权限处理带来额外兼容问题。[AC Linux 配置说明](https://github.com/sihawido/assettocorsa-linux-setup#fixing-crashes)

## 3. 路径与命令约定

默认路径如下；用户名变化时，**同时修改 Nix 字体路径、下列变量、CM 根目录和链接**。

本指南及附带工具按**默认库**编写，此时 Steam 客户端根目录与库目录是同一个路径。改用另一游戏库时，必须分别确认游戏目录、实际 `compatdata/244210` 位置和客户端 `config/loginusers.vdf` 来源。附带工具用 `--steam-root` 推导默认库前缀；非默认库需要调整这一推导，不能只把客户端根目录替换成新库路径。

| 用途 | Linux 路径 |
|---|---|
| Steam 根目录/默认库 | `/home/baizhu945/.local/share/Steam` |
| AC 游戏根目录 | `/home/baizhu945/.local/share/Steam/steamapps/common/assettocorsa` |
| 兼容数据目录 | `/home/baizhu945/.local/share/Steam/steamapps/compatdata/244210` |
| Wine 前缀 | 上一目录的 `pfx` |
| CM 数据与设置 | `pfx/drive_c/users/steamuser/AppData/Local/AcTools Content Manager` |
| 游戏文档/设置 | `pfx/drive_c/users/steamuser/Documents/Assetto Corsa` |
| CM 中填写的游戏路径 | `Z:\home\baizhu945\.local\share\Steam\steamapps\common\assettocorsa` |

`~/.steam/steam` 是指向默认 Steam 根目录的链接，不是另一个游戏副本。

本指南的命令按 **Bash** 编写，避免把 Bash 数组或脚本直接当作 zsh 代码运行。进入一个临时 Nix 环境：

```bash
nix-shell -p bash python3 winetricks curl unzip cabextract wget --run bash
```

在这个 Bash 会话中定义变量；将 `AC_SUPPORT_DIR` 改成附带脚本实际保存的位置：

```bash
export AC_STEAM_ROOT=/home/baizhu945/.local/share/Steam
export AC_GAME_DIR="$AC_STEAM_ROOT/steamapps/common/assettocorsa"
export AC_COMPAT_DIR="$AC_STEAM_ROOT/steamapps/compatdata/244210"
export AC_PREFIX_DIR="$AC_COMPAT_DIR/pfx"
export AC_CM_DIR="$AC_PREFIX_DIR/drive_c/users/steamuser/AppData/Local/AcTools Content Manager"
export AC_SUPPORT_DIR="/填写实际路径/ac-cm-support"
export AC_WORK_DIR="$PWD/work/ac-cm-reinstall"
export AC_BACKUP_DIR="$AC_WORK_DIR/backups/$(date +%Y%m%d-%H%M%S)"
mkdir -p "$AC_WORK_DIR" "$AC_BACKUP_DIR"
```

附带文件与指南应一起保存：

```text
AC-CM-NixOS-安装与迁移指南.md
ac-cm-support/
  nixos-ac-cm.nix
  runtime-env.nix
  install-dotnet48.sh
  stop-ac-prefix.py
  clean-host-fonts.py
  set-cm-root.py
```

这些脚本不含登录密码，不依赖本次聊天的 `work/ac-repair` 目录，也不固定历史 `/nix/store` 路径。脚本会修改所指定的 AC 前缀；执行前按下文停机并备份。

## 4. 声明式安装 Steam、Protontricks 与 AC 专用 GE

附带的 [nixos-ac-cm.nix](ac-cm-support/nixos-ac-cm.nix) 与当前已验证配置等价，包含：

1. `programs.steam.enable = true`。
2. `programs.steam.protontricks.enable = true`。
3. 固定 GE-Proton9-20 的下载地址及 `fetchzip` 哈希。
4. 字体 XML，只枚举 AC 前缀的 `Windows/Fonts`。
5. 在真正 Proton 启动前检查 App ID/Game ID/兼容目录，仅对 `244210` 设置 `FONTCONFIG_FILE`。

### 文件安装与导入

先在可写目录修改，而后复制到 `/etc/nixos`。`sudo` 密码在终端提示时输入，不应写在 Markdown、脚本或 Nix 文件里。

```bash
cp "$AC_SUPPORT_DIR/nixos-ac-cm.nix" "$AC_WORK_DIR/ac-cm.nix"
# 如果用户名/库路径不同，编辑该文件的 steamRoot。
nix-instantiate --parse "$AC_WORK_DIR/ac-cm.nix" >/dev/null
sudo cp "$AC_WORK_DIR/ac-cm.nix" /etc/nixos/ac-cm.nix

cp /etc/nixos/configuration.nix "$AC_BACKUP_DIR/configuration.nix"
cp /etc/nixos/configuration.nix "$AC_WORK_DIR/configuration.nix"
```

编辑可写副本的 `imports`，加入：

```nix
imports = [
  # 已有模块……
  ./ac-cm.nix
];
```

**已有这次配置的机器不要重复添加同一 GE 包。** 当前 `/etc/nixos/configuration.nix` 已经内联了相同 Steam 配置和 `acFontConfig`。可以直接保留现状；若改为导入模块，应移走原来的同一 GE `extraCompatPackages` 项及不再使用的 `acFontConfig`，避免注册两个同名工具。其他 Steam 配置仍保留。

```bash
nix-instantiate --parse "$AC_WORK_DIR/configuration.nix" >/dev/null
sudo cp "$AC_WORK_DIR/configuration.nix" /etc/nixos/configuration.nix
sudo nixos-rebuild switch
```

解析只检查语法；`nixos-rebuild switch` 才会完整求值、构建和激活。构建失败时先修复报错，不要继续使用未激活的新配置。

### 固定版本的核心配置

模块内的版本部分是：

```nix
version = "GE-Proton9-20";
toolName = "GE-Proton9-20";
steamDisplayName = "GE-Proton9-20";
src = pkgs.fetchzip {
  url = "https://github.com/GloriousEggroll/proton-ge-custom/releases/download/GE-Proton9-20/GE-Proton9-20.tar.gz";
  hash = "sha256-1twCv81KO1fcRcIb4H7VtAjtcKrX+DymsYdf885eOWo=";
};
```

`toolName` 与旧压缩包名没有新版 GE 的 `-x86_64` 后缀。这正是需要同时覆盖 `src` 和工具名的原因。`fetchzip` 哈希对应解压目录的递归内容，与原始压缩包的 SHA512 不是同一对象，不能互换。[固定 GE 发布页](https://github.com/GloriousEggroll/proton-ge-custom/releases/tag/GE-Proton9-20)、[fetchzip 文档](https://nixos.org/manual/nixpkgs/stable/#fetchzip)

这段包覆盖依赖当前 Nixpkgs 的 `proton-ge-bin` 输出结构；未来 Nixpkgs 若改动 `steamcompattool`、安装阶段或参数，需重新检查构建错误。本指南不会把未经验证的新包结构称为永久兼容。

## 5. 在 Steam 安装 AC，并初始化正确的前缀

1. 退出并重新启动 Steam，使新兼容工具被发现。
2. 选择默认库安装 **Assetto Corsa**，确认游戏目录内有 `acs.exe` 和原版 `AssettoCorsa.exe`。
3. 打开 **AC → Properties → Compatibility**，勾选强制使用兼容工具，选择 **GE-Proton9-20**。
4. 在 **General → Launch Options** 先填写：

   ```text
   PROTONFIXES_DISABLE=1 COMPlus_ZapDisable=1 HOST_LC_ALL=C.UTF-8 %command%
   ```

   临时关闭自动 protonfixes，便于按本指南控制原生 .NET 的安装过程。最后会恢复到已验证的最终启动项。

5. 点一次 PLAY，让 Steam 下载 Linux Runtime 3.0/sniper 并创建前缀。原版启动器此时可能报 CEF/.NET 错误；先确认前缀创建，不要连续点 PLAY。
6. 完成初始化后关闭游戏及 Steam，再继续安装依赖。

检查：

```bash
test -f "$AC_GAME_DIR/acs.exe"
test -f "$AC_PREFIX_DIR/system.reg"
cat "$AC_COMPAT_DIR/version"
```

应看到 GE-Proton9-20。前缀保持 **win64**；CM 本身是 x86，赛车本体使用 x64。不能为了安装 32 位 CM 把整个游戏前缀改成 win32。

## 6. 停机、备份与旧前缀处理

每次修改注册表、替换启动器或安装器运行前：

```bash
steam -shutdown
# 等 Steam 退出；如果它仍显示游戏运行中，先在界面停止。
```

若本次测试留下后台 AC/Wine 进程，可使用限定 App ID 前缀的工具：

```bash
python3 "$AC_SUPPORT_DIR/stop-ac-prefix.py" --steam-root "$AC_STEAM_ROOT"
```

它按 `WINEPREFIX`/`STEAM_COMPAT_DATA_PATH` 定位该前缀的同用户进程、发送 SIGTERM，并等待退出。只有出现 `AC prefix stopped`、命令成功结束后，才继续备份、移动前缀或运行安装器；30 秒超时会停止，不会自动强杀。不要对全部 Wine 进程运行 `killall`，其他应用可能也在使用 Wine。

备份兼容环境和用户设置：

```bash
cp -a --reflink=auto "$AC_COMPAT_DIR" "$AC_BACKUP_DIR/244210"
cp -a --reflink=auto "$AC_GAME_DIR/AssettoCorsa.exe" \
  "$AC_BACKUP_DIR/AssettoCorsa.exe"
```

若前缀此前由失败的 Experimental/Wine 版本反复修改，采用本次成功的干净重建路线：**把旧前缀移到备份目录**，回到第 5 节用固定 GE 初始化新的 `244210`。先保存 `Documents/Assetto Corsa` 和 CM 设置，不能直接删除存档。

```bash
# 只在决定重建前缀、且备份/停机完成后执行。
mv "$AC_COMPAT_DIR" "$AC_BACKUP_DIR/244210-old"
```

游戏安装目录不需要重新下载。若只更换硬件且现有环境能用，跳过此重建步骤。

## 7. 安装原生 .NET 4.8 与辅助库

### 7.1 先设置本次 CLI 会话的字体隔离

Nix 中的入口只在通过 Proton 启动 AC 时生效。`protontricks` 直接调用 Wine 的修复命令，也要显式设置字体配置，避免重新把宿主的大字体集注册进来：

```bash
python3 - <<'PY'
from pathlib import Path
import os
from xml.sax.saxutils import escape
p = Path(os.environ['AC_WORK_DIR']) / 'ac-fonts.conf'
font_dir = escape(str(Path(os.environ['AC_PREFIX_DIR']) / 'drive_c/windows/Fonts'))
p.write_text('<?xml version="1.0"?>\n'
             '<!DOCTYPE fontconfig SYSTEM "urn:fontconfig:fonts.dtd">\n'
             '<fontconfig>\n'
             f'  <dir>{font_dir}</dir>\n'
             '  <cachedir prefix="xdg">fontconfig/assetto-corsa</cachedir>\n'
             '</fontconfig>\n')
PY
export FONTCONFIG_FILE="$AC_WORK_DIR/ac-fonts.conf"
export PROTON_VERSION=GE-Proton9-20
```

这些变量只用于修复会话。正常启动走第 4 节的声明式 wrapper。

### 7.2 原生 .NET

通常先试标准入口：

```bash
protontricks --no-background-wineserver 244210 -q dotnet48
protontricks 244210 -q win10
```

`dotnet48` 会处理 Mono，并先安装 .NET 4.0 后升级到 4.8。安装过程中临时使用 Windows XP/7 模式是脚本流程，最后再设 `win10`。[Winetricks 源码](https://github.com/Winetricks/winetricks/blob/master/src/winetricks)

**如果 Mono 卸载不退出、安装器返回错误、或普通入口无法完成，使用已经成功的备用路线。** 本次是在一个完整 FHS 环境里，使用 GE 自带 Wine，在 Xvfb 图形会话中静默完成 .NET 安装：

```bash
# 先停机并备份；不要与上一轮安装器并行。
bash "$AC_SUPPORT_DIR/install-dotnet48.sh" \
  >"$AC_WORK_DIR/dotnet48-install.log" 2>&1
```

脚本会动态从传统 NixOS 配置取得当前固定 GE 的路径，构建含 FreeType/Fontconfig 和安装工具的临时 FHS 环境，并仅在本地副本中将 Mono 卸载改为 `msiexec /x UUID /qn /norestart`。它不修改系统 Winetricks、不安装非 Nix 包管理器，也不固定这次聊天的 store 地址。

若新 Winetricks 的 `load_remove_mono` 实现变化、补丁目标不再唯一，脚本会停止。应查看新实现后调整，不能用盲目字符串替换继续。

**此备用脚本是历史成功安装方式的可迁移封装；本次写指南仅检查了其语法与构建接口，没有在正在使用的前缀里重新执行安装。**

### 7.3 其余兼容库和字体

原生 .NET 完成后：

```bash
protontricks 244210 -q d3dx11_43 d3dcompiler_47 gdiplus corefonts win10
```

`gdiplus` 会取得并设置微软原版 GDI+；实际故障堆栈曾落在 `GdipCreateFontFamilyFromName`。字体缺失与 GDI+ 异常是两类问题，`gdiplus` 不能替代 `corefonts`。

GDI+ 的原生 DLL 安装可能下载较大的 Windows 安装介质，以提取 32/64 位 DLL；这不意味着把整套 Windows 装到系统上。

### 7.4 验证 .NET

```bash
protontricks -c \
  'wine reg query "HKLM\Software\Microsoft\NET Framework Setup\NDP\v4\Full" /v Version' \
  244210
protontricks -c \
  'wine reg query "HKLM\Software\Microsoft\NET Framework Setup\NDP\v4\Full" /v Release' \
  244210
protontricks 244210 list-installed
```

本次成功记录是 `Version=4.8.03761`、`Release=528049`（十六进制 `0x80eb1`），安装列表包含 `dotnet48`、`gdiplus`、`corefonts`。仅看到安装日志最后一行或一个占位文件，不足以证明安装成功。

后来自动修复的日志还出现 `dotnet452`，但原生 .NET 的版本仍为 4.8。不要仅凭 verb 名称推断实际 .NET 已降级。

## 8. 下载 CM、CSP 和官方字体

```bash
curl --fail --location --retry 3 \
  https://acstuff.club/app/tested.zip \
  --output "$AC_WORK_DIR/cm-tested.zip"
curl --fail --location --retry 3 \
  'https://acstuff.club/patch/?get=0.2.11' \
  --output "$AC_WORK_DIR/csp-0.2.11.zip"
curl --fail --location --retry 3 \
  https://acstuff.club/u/blob/ac-fonts.zip \
  --output "$AC_WORK_DIR/ac-fonts.zip"
```

CM 官网还提供 [offline.zip](https://acstuff.club/app/offline.zip)。优先使用官网入口；`tested.zip` 是移动文件，未来不一定是 0.8.2895.40668。[CM 官方页面](https://acstuff.club/app/)

已经保存了能用的 `Content Manager.exe` 时，可以使用它；原机器最初的文件来自 `/home/baizhu945/Downloads/CM/Content Manager.exe`。保存成功运行的更新后版本时，应保存游戏目录中的实际 `AssettoCorsa.exe`，因为 CM 更新可能只更新改名后的入口文件。

### 固定资源校验

本次保存的固定资源 SHA256：

```text
CSP 0.2.11:
0729ccaebb403a7a6d1c40516990da8116cb5f56eea4c1fe0bdd29863a5a6ffb

ac-fonts.zip:
c18efdf0ce4a36d9cecbd4f97b7f4b608bd2b6eca999b46ec2b4d93fb2de49b2
```

可用 `sha256sum` 核对。固定版本资源内容变化时应查明来源变化；CM 的移动 `tested.zip` 不使用旧哈希强行判断所有未来版本。

## 9. 将 CM 接到 Steam 的 PLAY

先解压 CM 到工作目录，确认其中是 `Content Manager.exe`。下面的 Python 只检查和解压 ZIP，不执行下载内容：

```bash
python3 - <<'PY'
from pathlib import Path
from zipfile import ZipFile
import os
work = Path(os.environ['AC_WORK_DIR'])
with ZipFile(work / 'cm-tested.zip') as z:
    for i in z.infolist():
        p = Path(i.filename)
        if p.is_absolute() or '..' in p.parts or ':' in i.filename or ((i.external_attr >> 16) & 0o170000) == 0o120000:
            raise SystemExit('Unsafe archive path')
    if z.testzip() is not None:
        raise SystemExit('ZIP CRC failed')
    z.extractall(work / 'cm-unpacked')
matches = list((work / 'cm-unpacked').rglob('Content Manager.exe'))
if len(matches) != 1:
    raise SystemExit('Check archive layout: expected one Content Manager.exe')
print(matches[0])
PY
```

关闭 Steam/CM；把原版启动器保留下来，然后用 CM 替代 Steam 入口：

```bash
if [ ! -f "$AC_GAME_DIR/AssettoCorsa_original.exe" ]; then
  cp -a "$AC_GAME_DIR/AssettoCorsa.exe" "$AC_GAME_DIR/AssettoCorsa_original.exe"
fi

# 将源路径替换为上一段实际输出的 Content Manager.exe。
cp "/实际解压路径/Content Manager.exe" "$AC_GAME_DIR/Content Manager.exe"
cp "$AC_GAME_DIR/Content Manager.exe" "$AC_GAME_DIR/AssettoCorsa.exe"
```

`acs.exe` 是赛车本体，不能覆盖。`AssettoCorsa.exe` 是 Steam 原先调用的启动器，改名替换方案保留 `244210` 的 Steam 运行环境。社区 Linux 安装流程也采用这种入口方式。[维护者说明](https://github.com/sihawido/assettocorsa-linux-setup)

### Steam 最终启动项

在 AC → Properties → General → Launch Options 设置：

```text
COMPlus_ZapDisable=1 HOST_LC_ALL=C.UTF-8 %command%
```

- `COMPlus_ZapDisable=1` 禁用 .NET NGen 预编译映像，采用这次实测稳定的加载方式，不会卸载 .NET。[微软说明](https://learn.microsoft.com/en-us/visualstudio/debugger/jit-optimization-and-debugging?view=visualstudio)
- `HOST_LC_ALL=C.UTF-8` 是 GE 会读取的宿主 locale 参数，保留 UTF-8 文件名。只设置 `LC_ALL=C` 可能被 Proton 的环境处理覆盖，且 ASCII locale 不适合包含重音/中文的路径。
- 字体隔离由 Nix wrapper 执行，最终启动项不需要引用工作目录。
- 当前高 DPI 桌面另外使用 `--ui-scale=1.5`：

  ```text
  COMPlus_ZapDisable=1 HOST_LC_ALL=C.UTF-8 %command% --ui-scale=1.5
  ```

  这属于界面缩放偏好。更换屏幕后按显示效果调整，不是游戏启动必需参数。

## 10. 字体与历史缓存处理：这台系统最重要的修复

原系统有约 **3.4 GiB 宿主字体**。Wine DirectWrite 会映射字体文件；日志中的 `0x524f0e8` 映射失败，精确对应一个约 82 MiB 的 Sarasa TTC。32 位 CM 的地址空间随后耗尽。这不是机器只有 4 GiB RAM，也不是增加物理内存就能解决的同一限制。[Wine DirectWrite 源码](https://github.com/ValveSoftware/wine/blob/proton_9.0/dlls/dwrite/font.c)

### 10.1 官方 UI 字体放在两个位置

- `AC/content/fonts/system`：官方字体包指定的 CSP/CM 相关文件位置。
- `前缀/drive_c/windows/Fonts`：让原生 WPF/Windows 字体解析能够找到真实字体。

```bash
python3 - <<'PY'
from pathlib import Path
from zipfile import ZipFile
import os, shutil
work = Path(os.environ['AC_WORK_DIR'])
game_fonts = Path(os.environ['AC_GAME_DIR']) / 'content/fonts/system'
wine_fonts = Path(os.environ['AC_PREFIX_DIR']) / 'drive_c/windows/Fonts'
game_fonts.mkdir(parents=True, exist_ok=True)
wine_fonts.mkdir(parents=True, exist_ok=True)
with ZipFile(work / 'ac-fonts.zip') as z:
    if z.testzip() is not None:
        raise SystemExit('ZIP CRC failed')
    for name in ('segoeui.ttf', 'verdana.ttf', 'verdanai.ttf'):
        data = z.read('system/' + name)
        for directory in (game_fonts, wine_fonts):
            target = directory / name
            if target.is_symlink():
                # Prevent writes through a symlink into immutable /nix/store.
                target.unlink()
            target.write_bytes(data)
print('Installed Segoe UI regular, Verdana and Verdana Italic.')
PY
```

这里装的是 Segoe UI **常规字体文件**，不是整套 Segoe UI 家族。`corefonts` 则补充 Arial 常规/粗体/斜体等常见字体及回退。

### 10.2 已有旧前缀才需要清理宿主字体注册

新前缀若从第一次启动起就经过 AC 专用 wrapper，通常不会积累这次规模的历史字体条目。若曾用普通 Wine、错误入口或未隔离配置启动，先停机再清理：

```bash
steam -shutdown
python3 "$AC_SUPPORT_DIR/stop-ac-prefix.py" --steam-root "$AC_STEAM_ROOT"
python3 "$AC_SUPPORT_DIR/clean-host-fonts.py" \
  --steam-root "$AC_STEAM_ROOT" \
  --backup-dir "$AC_BACKUP_DIR/registry-before-font-clean"
```

工具检查前缀进程完全停止，备份 `user.reg/system.reg`，仅删除这三处中指向宿主字体的绝对路径：

```text
user.reg:
Software\Wine\Fonts\External Fonts

system.reg:
Software\Microsoft\Windows\CurrentVersion\Fonts
Software\Microsoft\Windows NT\CurrentVersion\Fonts
```

它保留前缀相对字体名，以及前缀字体 symlink 的真实 `/nix/store` 目标；不会删除系统字体文件或其他注册表段。脚本拒绝运行时不要绕过检查，先确认遗留进程真正结束。

当时每处删除了 2,486 个宿主条目。**这个数字只是历史记录，不是未来必须相等的验收值。**

### 10.3 保证默认字体可解析

WPF 找不到可用字体时会退到 Arial；仍无法找到时可能 `FailFast`。仅减少字体数量还不够，必须有真实 Arial、Segoe UI/Verdana 及中文回退。[WPF 源码](https://github.com/dotnet/wpf/blob/main/src/Microsoft.DotNet.Wpf/src/PresentationCore/MS/internal/Shaping/TypefaceMap.cs)

可用临时隔离 XML 检查可见字体：

```bash
FONTCONFIG_FILE="$AC_WORK_DIR/ac-fonts.conf" fc-list -f '%{family}\n' | sort -u
```

应能看到 Arial、Segoe UI、Verdana、Times New Roman，以及已有的 SimSun/Microsoft Yahei 等中文字体。前缀字体集没有固定数量要求，但不应把整个 Sarasa/Noto 多字体库重新导入。

旧 GE 前缀曾包含把 Segoe UI/Verdana 替代成 Times New Roman 的 `Wine\Fonts\Replacements`。真实字体装齐后，如果界面仍错误替代，可在 `protontricks 244210 regedit` 中把该键**重命名为备份键**，保留原值供恢复。当前成功配置已保留备份并取消该旧替代。

## 11. 首次设置 CM、Steam 账号与 AC 根目录

### 11.1 映射 Steam 登录资料

先确认 Linux Steam 已登录；只链接文件，不需要把账号资料或密码写入指南：

```bash
AC_WINDOWS_STEAM="$AC_PREFIX_DIR/drive_c/Program Files (x86)/Steam"
mkdir -p "$AC_WINDOWS_STEAM/config"
if [ ! -e "$AC_WINDOWS_STEAM/config/loginusers.vdf" ] && \
   [ ! -L "$AC_WINDOWS_STEAM/config/loginusers.vdf" ]; then
  ln -s "$AC_STEAM_ROOT/config/loginusers.vdf" \
    "$AC_WINDOWS_STEAM/config/loginusers.vdf"
fi
```

CM 如果找不到该文件，可能不能自动识别 Steam ID。不要打印/公开整份 Steam 配置。游戏目录仍建议明确填写，不能依赖 Windows Steam 路径自动探测 Linux 库。

### 11.2 在向导里设置

从 Steam 点 PLAY，CM 向导中填写本指南第 3 节的 **Z: 游戏根目录**，确认找到 `acs.exe`，并识别 Steam 账号。

Linux/Wine 下不要在首次向导创建 Start Menu 快捷方式；需要桌面入口时使用 Steam 或 NixOS 管理的入口。[Linux 安装注意项](https://github.com/sihawido/assettocorsa-linux-setup#fixing-crashes)

在 CM 外观设置中关闭透明窗口。当前成功配置还为 **启动器 UI** 启用了软件渲染；它不是让赛车本体改用软件渲染。后续若新显卡能稳定渲染 CM，可以单独测试恢复 UI 硬件渲染。

### 11.3 向导探测失败时，预置配置

如果自动找 AC 根目录失败、向导无法完成，停止 CM 和前缀后运行：

```bash
python3 "$AC_SUPPORT_DIR/set-cm-root.py" \
  --steam-root "$AC_STEAM_ROOT" \
  --game-dir "$AC_GAME_DIR" \
  --backup-dir "$AC_BACKUP_DIR/cm-settings"
```

工具保留原有未知/加密字段，只更新已核实键：

```text
_ac_root                         Z:\home\…\assettocorsa
_wizardVersion                   2
_second_run                      0
appearance_disallowTransparency  1
appearance_softwareRendering     1
```

`Values.data` 不是普通 JSON：本基线使用版本 2 的转义 TAB 文本，可能有 LZF 压缩。工具会解压并写入 CM 接受的明文 v2。若未来 CM 改变格式/向导版本，工具会拒绝未知格式；应重新核对源码，而不是随意覆盖设置。[CM 根目录源码](https://github.com/gro-ove/actools/blob/master/AcManager.Tools/Managers/AcRootDirectory.cs)、[外观设置源码](https://github.com/gro-ove/actools/blob/master/AcManager.Controls/Presentation/AppAppearanceManager.cs)

## 12. 安装 CSP 0.2.11

### 正常界面路线

CM → **Settings → Custom Shaders Patch**，选择公共 **0.2.11** 并安装。按你确认的视频，CSP 是 CM 内安装的基础组件。[官方版本信息](https://acstuff.club/patch/?info=0.2.11)

安装完成应显示 **0.2.11 / 3465**。CM Lite 足够完成基础游戏启动与模组管理。

### CM 下载/安装不可用时的等价手动路线

这个路线在本机实际成功执行。关闭 CM/游戏，备份现有 `dwrite.dll/extension` 后，把官方 ZIP 的这两项解压到游戏根目录：

```text
assettocorsa/
  acs.exe
  AssettoCorsa.exe
  dwrite.dll
  extension/
```

不能多套一层 `csp-0.2.11/` 目录。CM 启动后仍应识别到 build 3465。

```bash
python3 - <<'PY'
from pathlib import Path
from zipfile import ZipFile
import os, shutil
root = Path(os.environ['AC_GAME_DIR'])
backup = Path(os.environ['AC_BACKUP_DIR']) / 'csp-before-install'
backup.mkdir(parents=True, exist_ok=True)
with ZipFile(Path(os.environ['AC_WORK_DIR']) / 'csp-0.2.11.zip') as z:
    for i in z.infolist():
        p = Path(i.filename)
        if p.is_absolute() or '..' in p.parts or ':' in i.filename or not p.parts:
            raise SystemExit('Unsafe archive path')
        if p.parts[0] not in ('dwrite.dll', 'extension'):
            raise SystemExit('Unexpected CSP archive layout')
        if ((i.external_attr >> 16) & 0o170000) == 0o120000:
            raise SystemExit('Unexpected symlink')
    if z.testzip() is not None:
        raise SystemExit('ZIP CRC failed')
    for name in ('dwrite.dll', 'extension'):
        if (root / name).exists() and (backup / name).exists():
            raise SystemExit('Backup destination already exists; choose a new backup directory')
    for name in ('dwrite.dll', 'extension'):
        item = root / name
        if item.exists():
            shutil.move(item, backup / name)
    z.extractall(root)
PY
```

GE 的 AC 自动修复设置 `dwrite=n,b`；必要时可显式写入该前缀：

```bash
protontricks -c \
  'wine reg add "HKCU\Software\Wine\DllOverrides" /v dwrite /t REG_SZ /d native,builtin /f' \
  244210
```

安装 CSP 后先验证原版车/赛道。不要同时导入大量车辆、物理、天气等模组，否则失败时难以确认来源。

## 13. CM 辅助数据包错误的修复

本次错误是：

```text
Can’t load CM’s data:
Could not find file '…\Data\Track Logos\Mods\Autódromo De Interlagos.png'
```

这是 **CM 辅助数据包解压失败**，影响图标、分类、品牌/国家信息与快速筛选，不表示赛车本体或 CSP 已损坏。源码把它报告为非致命更新错误。[DataUpdater 源码](https://github.com/gro-ove/actools/blob/master/AcManager.Tools/Data/DataUpdater.cs)

### 完整重装官方数据包

关闭 CM，保存原 Data 文件夹后，用 Linux/Python 解压，保留 Unicode 名字：

```bash
curl --fail --location --retry 3 \
  https://acstuff.club/app/cm/data/manifest \
  --output "$AC_WORK_DIR/cm-data-manifest.json"
curl --fail --location --retry 3 \
  https://acstuff.club/app/cm/data/latest \
  --output "$AC_WORK_DIR/cm-data.zip"

python3 - <<'PY'
from pathlib import Path
from zipfile import ZipFile
import json, os, shutil
work = Path(os.environ['AC_WORK_DIR'])
dest = Path(os.environ['AC_CM_DIR']) / 'Data'
backup = Path(os.environ['AC_BACKUP_DIR']) / 'cm-data-before-fix'
with ZipFile(work / 'cm-data.zip') as z:
    for i in z.infolist():
        p = Path(i.filename)
        if p.is_absolute() or '..' in p.parts or ':' in i.filename or ((i.external_attr >> 16) & 0o170000) == 0o120000:
            raise SystemExit('Unsafe archive path')
    if z.testzip() is not None:
        raise SystemExit('ZIP CRC failed')
    version = json.loads(z.read('Manifest.json'))['version']
    if str(version) != str(json.loads((work / 'cm-data-manifest.json').read_text())['version']):
        raise SystemExit('Manifest/version changed during download; download again')
    if dest.exists():
        if backup.exists():
            raise SystemExit('Backup destination exists; choose another directory')
        shutil.move(dest, backup)
    z.extractall(dest)
assert (dest / 'Online Filters/Quick Filters.json').is_file()
assert (dest / 'Track Logos/Mods/Autódromo De Interlagos.png').is_file()
print('Installed CM data version:', version)
PY
```

2026-10-13 官方端点与本机仍是版本 **245**。`latest` 以后可以变化，应核对 ZIP 内 Manifest 与官方端点，而非永久要求所有新包都等于 245。

这次 245 包 SHA256：

```text
c1df035945362c2179588c0fcf6a1a92bf9a4c695e709fcd722f65a9a4e6e962
```

不要把带重音字符的文件改成无重音拼写；CM 查找的是原始文件名。保留 `HOST_LC_ALL=C.UTF-8`，并用正常 Steam 入口验证下一次更新。

## 14. 按顺序验收

### 第一层：启动器

1. 通过普通 Steam PLAY 启动，不额外手工设置工作目录字体变量。
2. CM 主窗口持续显示，能看到车辆/赛道列表，文字可读。
3. CM 已识别实际游戏目录、Steam 账号与 CSP 0.2.11。
4. CM 日志显示数据版本 Installed 245/latest 245（或未来一致的新版本），没有重复的数据包错误。

### 第二层：赛车本体

1. 选择已安装的原版车辆和原版赛道，使用 Practice。
2. 点 CM 的 **Go!**，等待加载。
3. 真正赛车画面出现，能在赛道中操作。

只有 `Content Manager` 或 `Assetto Corsa Launcher` 窗口不算进入游戏；赛车本体进程是 `acs.exe`。本次用户已亲自确认可以进入游戏，这才是完成验证的依据。

### 第三层：重启与迁移持久性

1. 正常退出赛车、CM 和 Steam，重新启动 Steam，再点 PLAY。
2. 不依赖临时 `work` 目录环境变量，仍能启动。
3. Nix wrapper 在实际使用的固定 GE 包中；只有 AC 前缀受字体隔离。
4. 原版启动器备份存在；恢复指南与安装包已经保存在新的机器/备份介质上。

Steam 首次下载 runtime、处理 Vulkan 着色器可能耗时。这与几秒后 CEF/.NET 崩溃不同。按实际界面状态判断，避免反复点 PLAY 导致“Game already running”。

## 15. 常见报错对照

| 症状 | 判断与处理 |
|---|---|
| `CEF3` / `TypeLoadException` | 检查是否用错 `~/.wine`，是否原生 .NET 安装成功；使用同一 244210 前缀及 CM 入口。不要只补陌生 DLL。 |
| Mono 卸载/安装器长期等待 | 停止上一轮安装，保留日志；使用单一 FHS + Xvfb + 静默 Mono 卸载备用路线。 |
| `GdipCreateFontFamilyFromName` 访问异常 | 安装 `gdiplus`，同时检查真实 Corefonts/Segoe UI。 |
| `Not enough memory`、字体映射 OOM | 看是否枚举巨大宿主字体库；先验证 wrapper 和字体缓存，再判断物理 RAM。不要直接扩大/减少全局 ASLR。 |
| `TypefaceMap.MapUnresolvedCharacters` / `FailFast` | 回退字体不可用。补真实 Arial 常规、Segoe UI/Verdana，检查字体替代与路径。 |
| 原版启动器黑屏 | 这不是赛车画面。使用 CM 入口并处理字体/渲染；不能仅凭窗口进程存活宣称修复。 |
| CM 找不到 Steam ID | 检查 Linux Steam 登录状态与 Windows 前缀的 `loginusers.vdf` 链接。 |
| CM 找不到 AC 根目录 | 手工填 Z: 路径或用预置配置工具；路径应包含 `acs.exe`。 |
| 带重音文件名的数据包解压错误 | 用官方完整包和 Linux/Python Unicode 解压；核对 Manifest 和 Quick Filters。 |
| `Game already running` | 先确认上一轮 CM/赛车/前缀已结束，只做一次启动。必要时运行限定前缀的停止工具。 |
| Steam 校验后 PLAY 又打开原版启动器 | 校验/游戏更新可能恢复 Steam 管理的 `AssettoCorsa.exe`。备份当前 CM 后重新执行第 9 节入口替换。 |
| 更新后 `/nix/store` 字体链接失效 | 重建固定 GE、由它重建自带字体链接；恢复独立保存的 Corefonts/Segoe UI 实文件。 |

### 日志位置

```text
Linux Steam/logs/gameprocess_log.txt
Linux Steam/logs/console-linux.txt
…/Documents/Assetto Corsa/logs/launcher.log
…/AppData/Local/AcTools Content Manager/Logs/Main Log_*.log
```

需要 Proton 日志时临时加 `PROTON_LOG=1`，必要时指定 `PROTON_LOG_DIR`。定位完成后移除大量诊断输出；不要把旧日志里出现过的暂时 `d3d9=b`、禁用 XRandR、全局字体替换等尝试当作最终配置。

## 16. 备份、迁移与回滚

### 应保存什么

- 当前系统的 Steam/GE 字体 wrapper Nix 配置，或本指南的模块。
- 整个 `steamapps/compatdata/244210`。
- `Documents/Assetto Corsa` 中控制器、视频、车辆设置、回放等用户数据。
- CM 的 `AppData/Local/AcTools Content Manager`。
- 经过验证的 `AssettoCorsa.exe`（当前 CM）与 `AssettoCorsa_original.exe`。
- CSP `dwrite.dll`、`extension`，以及 `content` 中自己安装的车辆/赛道模组。
- 官方安装包及哈希。游戏本体可以由 Steam重新下载，但自己的模组通常不会自动回来。

不要把 Steam 登录资料、聊天里提供的 sudo 密码、激活密钥写进公共备份说明或上传到仓库。

### 保存真实字体，避免只保存 store 链接

Proton 自带字体包含指向 `/nix/store` 的 symlink。新系统/垃圾回收后旧路径可能失效。单独保存字体实文件：

```bash
cp -aL "$AC_PREFIX_DIR/drive_c/windows/Fonts" "$AC_BACKUP_DIR/Windows-Fonts-real"
```

完整前缀备份仍使用普通 `cp -a`/tar；不要对整个前缀盲目解引用，因为 `Z:`、用户文档等链接可能指向宿主的大范围目录。

### 恢复顺序

1. 新硬件对应驱动配置 → NixOS rebuild。
2. 声明固定 GE 与字体隔离 → Steam重新识别工具。
3. 下载/恢复 AC 到确定的 Linux 库。
4. 恢复前缀、用户设置、CM 与 CSP。
5. 修正用户名/库路径、Windows Steam链接、失效 store字体链接。
6. 再检查启动项，依次完成第 14 节的验收。

### 回到原版启动器

关闭 CM/Steam并备份当前 CM 后：

```bash
cp -a "$AC_GAME_DIR/AssettoCorsa.exe" "$AC_BACKUP_DIR/CM-active-AssettoCorsa.exe"
cp "$AC_GAME_DIR/AssettoCorsa_original.exe" "$AC_GAME_DIR/AssettoCorsa.exe"
```

恢复前缀时，把失败的新 `244210` 移到另一个备份目录，再复制已知能用的整个前缀，不在运行过程中覆盖注册表。若需要删除旧备份，使用机器上的 `remove-without-permission`；确认具体目标后再执行。

## 17. 最小成功清单

- [ ] 新硬件驱动及 32 位图形支持正确。
- [ ] 默认 Linux Steam 库；AC App ID 244210。
- [ ] Nix 声明固定 GE-Proton9-20 与启动前、AC 专属字体隔离。
- [ ] 原生 .NET 4.8、GDI+、D3D 辅助库与真实 Corefonts/Segoe UI。
- [ ] CM 与 AC 共用同一 win64 前缀。
- [ ] CM 根目录与 Steam账号资料链接正确。
- [ ] Steam PLAY 入口是 CM，原版启动器有备份。
- [ ] CSP 0.2.11/build 3465 识别正确。
- [ ] CM辅助数据完整，重音文件名保留。
- [ ] 正确启动项，普通 Steam 重启后仍有效。
- [ ] 原版车/原版赛道的赛车画面实际可进入。
- [ ] 工作配置、实文件字体、安装包及自己的模组均已备份。

## 18. 官方资料

- [CM 下载与依赖](https://acstuff.club/app/)
- [CSP 0.2.11 版本信息](https://acstuff.club/patch/?info=0.2.11)
- [GE-Proton9-20 官方发布](https://github.com/GloriousEggroll/proton-ge-custom/releases/tag/GE-Proton9-20)
- [Protontricks 用法](https://github.com/Matoking/protontricks#command-line)
- [Winetricks 原生依赖安装实现](https://github.com/Winetricks/winetricks/blob/master/src/winetricks)
- [CM 数据更新器](https://github.com/gro-ove/actools/blob/master/AcManager.Tools/Data/DataUpdater.cs)
- [CM 外观设置实现](https://github.com/gro-ove/actools/blob/master/AcManager.Controls/Presentation/AppAppearanceManager.cs)
- [本次基础教程](https://www.bilibili.com/video/BV14k4y1U7q2/)

本指南记录的是已经成功的程序、路径、配置与修复组合。更换 CPU/GPU 通常不需要改变这些应用层步骤；变更用户名、库路径、系统架构、Nixpkgs 接口或程序版本时，则应按对应检查点重新验证。
