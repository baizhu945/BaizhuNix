{ pkgs, ... }:

let
  # Change this path if the login name or Steam library changes.
  steamRoot = "/home/baizhu945/.local/share/Steam";
  acFontConfig = pkgs.writeText "assetto-corsa-fontconfig.conf" ''
    <?xml version="1.0"?>
    <!DOCTYPE fontconfig SYSTEM "urn:fontconfig:fonts.dtd">
    <fontconfig>
      <dir>${steamRoot}/steamapps/compatdata/244210/pfx/drive_c/windows/Fonts</dir>
      <cachedir prefix="xdg">fontconfig/assetto-corsa</cachedir>
    </fontconfig>
  '';
in
{
  programs.steam = {
    enable = true;
    protontricks.enable = true;
    extraCompatPackages = [
      (pkgs.proton-ge-bin.overrideAttrs (finalAttrs: old: {
        version = "GE-Proton9-20";
        toolName = "GE-Proton9-20";
        steamDisplayName = "GE-Proton9-20";
        src = pkgs.fetchzip {
          url = "https://github.com/GloriousEggroll/proton-ge-custom/releases/download/GE-Proton9-20/GE-Proton9-20.tar.gz";
          hash = "sha256-1twCv81KO1fcRcIb4H7VtAjtcKrX+DymsYdf885eOWo=";
        };
        postInstall = (old.postInstall or "") + ''
          ${pkgs.coreutils}/bin/unlink "$steamcompattool/proton"
          cp ${pkgs.writeScript "proton-ac-fontconfig" ''
            #!${pkgs.runtimeShell}
            acCompatPath="''${STEAM_COMPAT_DATA_PATH:-}"
            acCompatPath="''${acCompatPath%/}"
            if [[ "''${SteamAppId:-}" == 244210 ||
                  "''${SteamGameId:-}" == 244210 ||
                  "$acCompatPath" == */compatdata/244210 ]]; then
              export FONTCONFIG_FILE=${acFontConfig}
            fi
            exec "${finalAttrs.src}/proton" "$@"
          ''} "$steamcompattool/proton"
        '';
      }))
    ];
  };
}
