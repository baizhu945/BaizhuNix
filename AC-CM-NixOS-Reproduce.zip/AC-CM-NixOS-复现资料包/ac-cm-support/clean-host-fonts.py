#!/usr/bin/env python3
"""Remove only host-font registrations from AC's stopped Proton prefix.

Never changes host fonts, the system font configuration, or other registry
sections. Run only after AC/CM and their prefix processes have stopped, with
the isolated FONTCONFIG_FILE ready for the next launch.

Wine 9 font.c load_registry_fonts() otherwise reimports old host-font paths
even after Fontconfig's visible directories have been restricted. The Wine
font cache key is REG_OPTION_VOLATILE and disappears with the prefix's server;
this script does not modify that cache or any other registry section.
"""

from __future__ import annotations

from collections import Counter
import argparse
import os
from pathlib import Path
import re
import shutil
import stat
import tempfile


parser = argparse.ArgumentParser(description="Clean only host-font entries in a stopped AC prefix")
parser.add_argument("--steam-root", type=Path, default=Path.home() / ".local/share/Steam")
parser.add_argument("--backup-dir", type=Path, required=True)
args = parser.parse_args()
PREFIX = (args.steam_root / "steamapps/compatdata/244210/pfx").resolve()
BACKUPS = args.backup_dir.resolve()
USER_FONT_DIR = str(Path.home() / ".local/share/fonts").casefold().rstrip("/") + "/"
TARGET_SECTIONS = {
    "user.reg": {r"Software\\Wine\\Fonts\\External Fonts"},
    "system.reg": {
        r"Software\\Microsoft\\Windows\\CurrentVersion\\Fonts",
        r"Software\\Microsoft\\Windows NT\\CurrentVersion\\Fonts",
    },
}
SECTION_RE = re.compile(r"^\[([^\]]+)\]")
STRING_ENTRY_RE = re.compile(r'^"(?:[^"\\]|\\.)*"="((?:[^"\\]|\\.)*)"\s*$')


def registry_unescape(value: str) -> str:
    """Decode Wine registry string escaping, without evaluating its text."""
    output: list[str] = []
    offset = 0
    escapes = {"\\": "\\", '"': '"', "n": "\n", "r": "\r", "t": "\t"}
    while offset < len(value):
        char = value[offset]
        offset += 1
        if char == "\\" and offset < len(value):
            escaped = value[offset]
            offset += 1
            if escaped not in escapes:
                # Unknown escapes are not candidate paths; never broaden a match.
                return ""
            output.append(escapes[escaped])
        else:
            output.append(char)
    return "".join(output)


def prefix_font_whitelist() -> set[str]:
    """Keep Proton's bundled fonts even if registry paths use /nix/store."""
    allowed: set[str] = set()
    directory = PREFIX / "drive_c/windows/Fonts"
    if not directory.is_dir():
        raise RuntimeError("Prefix Windows/Fonts is missing; refusing edits")
    for font in directory.rglob("*"):
        if font.is_file():
            allowed.add(str(font).casefold())
            allowed.add(str(font.resolve()).casefold())
    if not allowed:
        raise RuntimeError("Prefix Windows/Fonts is empty; refusing edits")
    return allowed


def is_host_font_path(encoded_value: str, whitelist: set[str]) -> bool:
    value = registry_unescape(encoded_value).replace("\\", "/")
    if value.casefold().startswith("/??/") or value.casefold().startswith("//?/"):
        value = value[4:]
    if value.casefold().startswith("z:/"):
        value = value[2:]
    elif not value.startswith("/"):
        # Includes relative file names and C:\\Windows\\Fonts paths.
        return False
    lowered = value.casefold()
    if lowered in whitelist or str(Path(value).resolve()).casefold() in whitelist:
        return False
    return (
        lowered.startswith("/run/")
        or lowered.startswith("/nix/")
        or lowered.startswith(USER_FONT_DIR)
    )


def same_prefix(value: bytes) -> bool:
    try:
        return Path(os.fsdecode(value)).resolve() == PREFIX.resolve()
    except (OSError, ValueError):
        return False


def ensure_prefix_stopped() -> None:
    """Check prefix-specific environments and Wine/Proton command lines privately."""
    active = 0
    unknown = 0
    uid = os.getuid()
    own_pid = os.getpid()
    for process in Path("/proc").iterdir():
        if not process.name.isdecimal() or int(process.name) == own_pid:
            continue
        try:
            if process.stat().st_uid != uid:
                continue
            arguments = (process / "cmdline").read_bytes().split(b"\0")
            command = arguments[0].rsplit(b"/", 1)[-1].lower() if arguments else b""
            wine_like = (
                command.startswith(b"wine")
                or command in (b"proton", b"protontricks", b"protontricks-launch")
                or any(arg.lower().endswith(b".exe") for arg in arguments if arg)
                or any(arg.rsplit(b"/", 1)[-1] == b"proton" for arg in arguments if arg)
            )
            if not wine_like:
                continue
            environment = (process / "environ").read_bytes().split(b"\0")
            relevant: dict[bytes, bytes] = {}
            for entry in environment:
                key, separator, value = entry.partition(b"=")
                if separator and key in (b"WINEPREFIX", b"STEAM_COMPAT_DATA_PATH"):
                    relevant[key] = value
            target = same_prefix(relevant[b"WINEPREFIX"]) if b"WINEPREFIX" in relevant else False
            if b"STEAM_COMPAT_DATA_PATH" in relevant:
                target |= same_prefix(relevant[b"STEAM_COMPAT_DATA_PATH"].rstrip(b"/") + b"/pfx")
            if not target:
                # Covers a runner still preparing the prefix before WINEPREFIX exists.
                target = any(
                    os.fsencode(str(PREFIX)) in arg
                    or os.fsencode(str(PREFIX.parent)) in arg
                    for arg in arguments
                )
            if target:
                active += 1
        except FileNotFoundError:
            continue  # Process exited during this read.
        except PermissionError:
            unknown += 1
    if active:
        raise RuntimeError(f"Refusing registry edits: {active} AC prefix Wine/Proton process(es) are running")
    if unknown:
        raise RuntimeError("Refusing registry edits: could not inspect a same-user Wine/Proton process")


def prepare_file(filename: str, whitelist: set[str]) -> tuple[bytes, bytes, Counter[str], int]:
    path = PREFIX / filename
    original = path.read_bytes()
    text = original.decode("utf-8", errors="surrogateescape")
    if not text.startswith("WINE REGISTRY Version 2"):
        raise ValueError(f"Unexpected Wine registry format in {filename}")
    section = ""
    seen: set[str] = set()
    deleted: Counter[str] = Counter()
    retained: list[str] = []
    for line in text.splitlines(keepends=True):
        section_match = SECTION_RE.match(line)
        if section_match:
            section = section_match.group(1)
            if section in TARGET_SECTIONS[filename]:
                seen.add(section)
        if section in TARGET_SECTIONS[filename]:
            entry = STRING_ENTRY_RE.match(line)
            if entry and is_host_font_path(entry.group(1), whitelist):
                deleted[section] += 1
                continue
        retained.append(line)
    missing = TARGET_SECTIONS[filename] - seen
    if missing:
        raise ValueError(f"Required font registry section is missing in {filename}")
    replacement = "".join(retained).encode("utf-8", errors="surrogateescape")
    return original, replacement, deleted, stat.S_IMODE(path.stat().st_mode)


def atomic_replace(path: Path, data: bytes, mode: int) -> None:
    temporary: str | None = None
    try:
        with tempfile.NamedTemporaryFile(dir=path.parent, prefix=f"{path.name}.fonts-", delete=False) as stream:
            temporary = stream.name
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(temporary, mode)
        os.replace(temporary, path)
        temporary = None
    finally:
        if temporary is not None:
            Path(temporary).unlink(missing_ok=True)


def main() -> None:
    ensure_prefix_stopped()
    whitelist = prefix_font_whitelist()
    prepared = {filename: prepare_file(filename, whitelist) for filename in TARGET_SECTIONS}
    # Prepare and verify every edit before creating backups or replacing files.
    ensure_prefix_stopped()
    for filename, (original, _, _, _) in prepared.items():
        if (PREFIX / filename).read_bytes() != original:
            raise RuntimeError("Registry changed during preparation; refusing edits")
    BACKUPS.mkdir(parents=True, exist_ok=True)
    for filename in TARGET_SECTIONS:
        backup = BACKUPS / filename
        if not backup.exists():
            shutil.copy2(PREFIX / filename, backup)
    ensure_prefix_stopped()
    for filename, (original, replacement, deleted, mode) in prepared.items():
        if (PREFIX / filename).read_bytes() != original:
            raise RuntimeError("Registry changed before replacement; refusing further edits")
        if replacement != original:
            atomic_replace(PREFIX / filename, replacement, mode)
        for section in sorted(TARGET_SECTIONS[filename]):
            label = section.replace("\\\\", "\\")
            print(f"{filename}: {label}: removed {deleted[section]} host-font entries")
    print(f"Backups: {BACKUPS}")
    print("Other registry sections and all real font files were preserved.")


if __name__ == "__main__":
    main()
