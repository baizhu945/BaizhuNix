#!/usr/bin/env python3
"""Preconfigure the existing CM storage after stopping AC and Content Manager.

CM source references (gro-ove/actools, master):
  AcManager.Tools/Managers/AcRootDirectory.cs: Key = "_ac_root"
  AcManager/Pages/Dialogs/AcRootDirectorySelector.xaml.cs:
    WizardVersion = "2", KeyWizardVersion = "_wizardVersion"
    KeyFirstRun = "_second_run"
  FirstFloor.ModernUI/Helpers/Storage.cs:
    LzfFlag = 11; uncompressed UTF-8 version-2 storage is also accepted.
    Backslash, newline and tab are escaped; entries use literal tabs.

Existing values are preserved without displaying them. The known CM appearance
keys disable transparency and enable software rendering for the launcher UI.
"""

from __future__ import annotations

import os
import argparse
from pathlib import Path
import shutil
import stat
import tempfile
import zlib


parser = argparse.ArgumentParser(description="Preconfigure CM storage with an explicit AC game root")
parser.add_argument("--steam-root", type=Path, default=Path.home() / ".local/share/Steam")
parser.add_argument("--game-dir", type=Path)
parser.add_argument("--backup-dir", type=Path, required=True)
args = parser.parse_args()
PREFIX = (args.steam_root / "steamapps/compatdata/244210/pfx").resolve()
STORAGE = PREFIX / "drive_c/users/steamuser/AppData/Local/AcTools Content Manager/Values.data"
BACKUP = args.backup_dir.resolve() / "Values.data.before-root"
game_dir = (args.game_dir or args.steam_root / "steamapps/common/assettocorsa").resolve()
if not (game_dir / "acs.exe").is_file():
    raise SystemExit("Game root must contain acs.exe")
AC_ROOT = "Z:" + str(game_dir).replace("/", "\\")



def decompress_lzf(data: bytes) -> bytes:
    """Decode the raw LZF stream following CM's byte-11 marker."""
    output = bytearray()
    offset = 0
    while offset < len(data):
        control = data[offset]
        offset += 1
        if control < 32:
            length = control + 1
            if offset + length > len(data):
                raise ValueError("Truncated LZF literal")
            output.extend(data[offset : offset + length])
            offset += length
            continue

        length = control >> 5
        reference = len(output) - ((control & 31) << 8) - 1
        if length == 7:
            if offset >= len(data):
                raise ValueError("Truncated LZF length")
            length += data[offset]
            offset += 1
        if offset >= len(data):
            raise ValueError("Truncated LZF reference")
        reference -= data[offset]
        offset += 1
        if reference < 0:
            raise ValueError("Invalid LZF reference")
        for _ in range(length + 2):
            if reference >= len(output):
                raise ValueError("Invalid LZF overlapping reference")
            output.append(output[reference])
            reference += 1
    return bytes(output)


def decode_storage(data: bytes) -> str:
    if not data:
        raise ValueError("Values.data is empty")
    if data[0] == 11:
        data = decompress_lzf(data[1:])
    elif data[0] == 0:
        data = zlib.decompress(data[1:], -zlib.MAX_WBITS)
    elif any(c < 32 and c not in (9, 10, 13) for c in data):
        raise ValueError("Unrecognized storage compression format")
    return data.decode("utf-8")


def decode_field(value: str) -> str:
    output: list[str] = []
    offset = 0
    replacements = {"\\": "\\", "n": "\n", "t": "\t"}
    while offset < len(value):
        char = value[offset]
        offset += 1
        if char != "\\":
            output.append(char)
        elif offset < len(value):
            escaped = value[offset]
            offset += 1
            if escaped in replacements:
                output.append(replacements[escaped])
    return "".join(output)


def encode_field(value: str) -> str:
    return (
        value.replace("\\", "\\\\")
        .replace("\n", "\\n")
        .replace("\t", "\\t")
        .replace("\b", "")
        .replace("\r", "")
    )


def same_prefix(value: bytes) -> bool:
    try:
        return Path(os.fsdecode(value)).resolve() == PREFIX.resolve()
    except (OSError, ValueError):
        return False


def ensure_prefix_stopped() -> None:
    """Check prefix-specific environments and Wine/Proton command lines privately."""
    active = 0
    unknown = 0
    uid = os.getuid()
    own_pid = os.getpid()
    for process in Path("/proc").iterdir():
        if not process.name.isdecimal() or int(process.name) == own_pid:
            continue
        try:
            if process.stat().st_uid != uid:
                continue
            arguments = (process / "cmdline").read_bytes().split(b"\0")
            command = arguments[0].rsplit(b"/", 1)[-1].lower() if arguments else b""
            wine_like = (
                command.startswith(b"wine")
                or command in (b"proton", b"protontricks", b"protontricks-launch")
                or any(arg.lower().endswith(b".exe") for arg in arguments if arg)
                or any(arg.rsplit(b"/", 1)[-1] == b"proton" for arg in arguments if arg)
            )
            if not wine_like:
                continue
            environment = (process / "environ").read_bytes().split(b"\0")
            relevant: dict[bytes, bytes] = {}
            for entry in environment:
                key, separator, value = entry.partition(b"=")
                if separator and key in (b"WINEPREFIX", b"STEAM_COMPAT_DATA_PATH"):
                    relevant[key] = value
            target = same_prefix(relevant[b"WINEPREFIX"]) if b"WINEPREFIX" in relevant else False
            if b"STEAM_COMPAT_DATA_PATH" in relevant:
                target |= same_prefix(relevant[b"STEAM_COMPAT_DATA_PATH"].rstrip(b"/") + b"/pfx")
            if not target:
                # Covers a runner still preparing the prefix before WINEPREFIX exists.
                target = any(
                    os.fsencode(str(PREFIX)) in arg
                    or os.fsencode(str(PREFIX.parent)) in arg
                    for arg in arguments
                )
            if target:
                active += 1
        except FileNotFoundError:
            continue  # Process exited during this read.
        except PermissionError:
            unknown += 1
    if active:
        raise RuntimeError(f"Refusing registry edits: {active} AC prefix Wine/Proton process(es) are running")
    if unknown:
        raise RuntimeError("Refusing registry edits: could not inspect a same-user Wine/Proton process")



def main() -> None:
    ensure_prefix_stopped()
    original = STORAGE.read_bytes() if STORAGE.exists() else b"version: 2\n"
    lines = decode_storage(original).replace("\r\n", "\n").replace("\r", "\n").split("\n")
    if not lines or lines[0] != "version: 2":
        raise ValueError("Expected CM storage version 2; refusing to replace it")

    # Keep the original encoded fields, including encrypted/private values.
    entries: dict[str, tuple[str, str]] = {}
    for line in lines[1:]:
        if not line:
            continue
        if line.count("\t") != 1:
            raise ValueError("Malformed version-2 storage entry")
        key, value = line.split("\t", 1)
        entries[decode_field(key)] = (key, value)

    updates = {
        "_ac_root": AC_ROOT,
        "_wizardVersion": "2",
        # Storage.AsShort serializes booleans as 0/1; both forms are accepted.
        "_second_run": "0",
        "appearance_disallowTransparency": "1",
        "appearance_softwareRendering": "1",
    }
    for key, value in updates.items():
        entries[key] = (encode_field(key), encode_field(value))
    replacement = (
        "version: 2\n" + "\n".join(f"{key}\t{value}" for key, value in entries.values())
    ).encode("utf-8")

    BACKUP.parent.mkdir(parents=True, exist_ok=True)
    STORAGE.parent.mkdir(parents=True, exist_ok=True)
    if STORAGE.exists() and not BACKUP.exists():
        shutil.copy2(STORAGE, BACKUP)
        BACKUP.chmod(0o600)
    mode = stat.S_IMODE(STORAGE.stat().st_mode) if STORAGE.exists() else 0o600
    temporary_name: str | None = None
    try:
        with tempfile.NamedTemporaryFile(dir=STORAGE.parent, prefix="Values.data.root-", delete=False) as stream:
            temporary_name = stream.name
            stream.write(replacement)
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(temporary_name, mode)
        os.replace(temporary_name, STORAGE)
        temporary_name = None
    finally:
        if temporary_name is not None:
            Path(temporary_name).unlink(missing_ok=True)

    print("Preserved existing CM values; configured AC root and wizard version 2.")
    print(f"Backup: {BACKUP}")
    print("Configured CM software rendering and disabled window transparency.")


if __name__ == "__main__":
    main()
