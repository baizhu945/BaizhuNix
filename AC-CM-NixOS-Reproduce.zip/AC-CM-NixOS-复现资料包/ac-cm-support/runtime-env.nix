let
  pkgs = import <nixpkgs> { config.allowUnfree = true; };
in
(pkgs.steam.override {
  extraPkgs = p: with p; [ winetricks cabextract unzip wget curl xvfb-run ];
  extraLibraries = p: with p; [ freetype fontconfig ];
}).run
