#!/usr/bin/env bash
set -euo pipefail

if [[ "${AC_INSTALL_IN_FHS:-0}" == 1 ]]; then
  export WINEPREFIX="$AC_PREFIX_DIR"
  export WINE="$AC_GE_TOOL/files/bin/wine"
  export WINE64="$AC_GE_TOOL/files/bin/wine64"
  export WINESERVER="$AC_GE_TOOL/files/bin/wineserver"
  export WINEARCH=win64 WINEFSYNC=0 WINEESYNC=0 WINEDEBUG=-all
  export FONTCONFIG_FILE="$AC_WORK_DIR/ac-fonts.conf"
  trap '"$WINESERVER" -k >/dev/null 2>&1 || true' EXIT
  # Everything below runs in one FHS session, including the virtual X display.
  xvfb-run -a -s '-screen 0 1280x720x24' \
    bash "$AC_WORK_DIR/winetricks-quiet-mono" -q dotnet48 win10
  exit 0
fi

: "${AC_STEAM_ROOT:=$HOME/.local/share/Steam}"
: "${AC_PREFIX_DIR:=$AC_STEAM_ROOT/steamapps/compatdata/244210/pfx}"
: "${AC_WORK_DIR:=$PWD/work/ac-cm-reinstall}"
AC_SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
AC_INSTALL_SCRIPT="$AC_SCRIPT_DIR/install-dotnet48.sh"
mkdir -p "$AC_WORK_DIR"
AC_WORK_DIR="$(cd -- "$AC_WORK_DIR" && pwd)"

if [[ ! -f "$AC_PREFIX_DIR/system.reg" ]]; then
  printf '%s\n' 'Initialize AC App ID 244210 with GE-Proton9-20 in Steam first.' >&2
  exit 1
fi

# This is the configured package, not a historical /nix/store path.
AC_GE_TOOL="$(nix-build --no-out-link -E '
  let
    s = import <nixpkgs/nixos> {};
    ps = builtins.filter (p: (p.version or "") == "GE-Proton9-20")
      s.config.programs.steam.extraCompatPackages;
  in
    assert builtins.length ps == 1;
    (builtins.head ps).steamcompattool
')"
test -x "$AC_GE_TOOL/files/bin/wine"
AC_FHS_RUNNER="$(nix-build --no-out-link "$AC_SCRIPT_DIR/runtime-env.nix")/bin/steam-run"
test -x "$AC_FHS_RUNNER"

AC_WINETRICKS_REAL="$(readlink -f -- "$(command -v winetricks)")"
AC_WINETRICKS_SOURCE="$(dirname -- "$AC_WINETRICKS_REAL")/.winetricks-wrapped"
if [[ ! -f "$AC_WINETRICKS_SOURCE" ]]; then
  AC_WINETRICKS_SOURCE="$AC_WINETRICKS_REAL"
fi
export AC_STEAM_ROOT AC_PREFIX_DIR AC_WORK_DIR AC_GE_TOOL AC_INSTALL_SCRIPT AC_WINETRICKS_SOURCE

python3 - <<'PY'
from pathlib import Path
import os
from xml.sax.saxutils import escape

prefix = str(Path(os.environ['AC_PREFIX_DIR']).resolve()).encode()
for process in Path('/proc').iterdir():
    if not process.name.isdecimal() or int(process.name) == os.getpid():
        continue
    try:
        if process.stat().st_uid != os.getuid():
            continue
        env = dict(x.split(b'=', 1) for x in (process / 'environ').read_bytes().split(b'\0') if b'=' in x)
        if env.get(b'WINEPREFIX', b'').rstrip(b'/') == prefix or env.get(b'STEAM_COMPAT_DATA_PATH', b'').rstrip(b'/') + b'/pfx' == prefix:
            raise SystemExit('AC prefix is running. Stop it before installing .NET.')
    except (FileNotFoundError, PermissionError):
        continue
source = Path(os.environ['AC_WINETRICKS_SOURCE'])
text = source.read_text()
old = '"${WINE_ARCH}" uninstaller --remove "${mono_uuid}"'
new = '"${WINE_ARCH}" msiexec /x "${mono_uuid}" /qn /norestart'
if text.count(old) != 1:
    raise SystemExit('Winetricks has changed. Review load_remove_mono; no patch was applied.')
work = Path(os.environ['AC_WORK_DIR'])
patched = work / 'winetricks-quiet-mono'
patched.write_text(text.replace(old, new))
patched.chmod(0o700)
font_dir = escape(str(Path(os.environ['AC_PREFIX_DIR']) / 'drive_c/windows/Fonts'))
(work / 'ac-fonts.conf').write_text(
    '<?xml version="1.0"?>\n'
    '<!DOCTYPE fontconfig SYSTEM "urn:fontconfig:fonts.dtd">\n'
    '<fontconfig>\n'
    f'  <dir>{font_dir}</dir>\n'
    '  <cachedir prefix="xdg">fontconfig/assetto-corsa</cachedir>\n'
    '</fontconfig>\n'
)
PY

export AC_INSTALL_IN_FHS=1
exec "$AC_FHS_RUNNER" bash "$AC_INSTALL_SCRIPT"
