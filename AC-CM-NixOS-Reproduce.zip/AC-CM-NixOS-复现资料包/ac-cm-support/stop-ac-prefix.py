from pathlib import Path
import os
import signal
import argparse
import time

parser = argparse.ArgumentParser(description="Stop only processes tied to AC App ID 244210")
parser.add_argument("--steam-root", type=Path, default=Path.home() / ".local/share/Steam")
args = parser.parse_args()
prefix = str((args.steam_root / "steamapps/compatdata/244210/pfx").resolve())
def prefix_processes():
    result = []
    for p in Path('/proc').iterdir():
        if not p.name.isdigit() or int(p.name) == os.getpid():
            continue
        try:
            if p.stat().st_uid != os.getuid():
                continue
            env = dict(x.split(b'=', 1) for x in (p / 'environ').read_bytes().split(b'\0') if b'=' in x)
            if env.get(b'WINEPREFIX', b'').decode(errors='ignore').rstrip('/') == prefix or env.get(b'STEAM_COMPAT_DATA_PATH', b'').decode(errors='ignore').rstrip('/') == prefix[:-4]:
                result.append(int(p.name))
        except (FileNotFoundError, PermissionError, ProcessLookupError):
            pass
    return result

ids = prefix_processes()
for pid in ids:
    try:
        os.kill(pid, signal.SIGTERM)
    except ProcessLookupError:
        pass
deadline = time.monotonic() + 30
while prefix_processes():
    if time.monotonic() >= deadline:
        raise SystemExit('AC prefix still has running processes; do not back up or edit it yet.')
    time.sleep(0.25)
print('AC prefix stopped. Processes signalled:', len(ids))
